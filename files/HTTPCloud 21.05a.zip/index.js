/* Gohoski still owns this code.
scratch.mit.edu/users/Gohoski
youtube.com/channel/UCAmaZiDzCc47iw5orRZLbzw
github.com/gohoski */

const keep_alive = require('./keep_alive.js')
const request = require('request');
var Scratch = require('scratch-api');
const config = require('./config.json');
const fs = require('fs');
var letters;
fs.readFile('letters.txt', (err, text) => {
	if (err) throw err;
	letters = text.toString().split('\r\n');
});
function decode(text) {
	var result = '', letterNum = 0;
	for(var i = 0; i < text.length / 2; i++) {
		var temp = [text[letterNum], text[letterNum + 1]];
		result = result + letters[temp.join('') - 1];
		letterNum = letterNum + 2;
	}
	return result;
}
function encode(textNotLowerCase) {
  var result = '', letterNum = 0, text = textNotLowerCase.toLowerCase();
  for(var i = 0; i < text.length; i++) {
    var number = letters.indexOf(text[letterNum]) + 1;
    if(number > 10) {
      result = result + number;
    } else {
      result = result + '0' + number;
    }
    letterNum++;
  }
  if (result.includes('-')) {
    return '18051916151419059503151420010914199519251302151219952008012095011805951415209519211616151820050443';
  } else {
    return result;
  }
}

Scratch.UserSession.create(config.username, config.password, (err, user) => {
	if (err) return console.log(`Ой! Произошла ошибка. Возможно, вы неправильно написали свой ник и(ли) пароль в файле "config.json". Если нет, то напишите это Гохоски:
${err}`);
  console.log(`Успешно вошли в аккаунт с ником ${config.username}! Подключаемся к проекту с ID ${config.projectID}...`)
	user.cloudSession(config.projectID, (err, cloudSession) => {
		if (err) return console.log(`Произошла ошибка. Возможно, вы неправильно написали ID проекта в файле "config.json". Если нет, то отправьте это Гохоски:
${err}`);
    console.log('Успешно подключились к проекту! :)');
		cloudSession.on('set', (name, value) => {
			if (name === '☁ HTTPCloud_req') {
        if (value.startsWith('76599')) {
          var id = value.slice(5);
          console.log(`Юзер захотел посмотреть проект с ID ${id}, делаем реквест...`);
          request(`https://clouddata.scratch.mit.edu/logs?projectid=${id}&limit=10&offset=0`, { json: true }, (error, response, body) => {
            if (error) {
              console.log(`Произошла ошибка "${error.message}" пока делали реквест! :( Говорим это пользователю...`);
              cloudSession.set('☁ HTTPCloud_res', encode(error.message));
              console.log('Мы сказали это пользователю.');
            } else {
              var response = new Array(), temp;
              for(var i = 1; i < body.length; i++) {
                if(response.join().length > 128) break;
                response[i] = `${body[i].user}|${body[i].verb}|${body[i].name.slice(2)}|${body[i].value}`;
              }
              delete response[response.length - 1];
              console.log('Никаких ошибок не произошло! :) Говорим это пользователю...');
              cloudSession.set('☁ HTTPCloud_res', encode(response.join().slice(1)));
              console.log('Сказали это пользователю!');
            }
          });
        } else {
          var url = decode(value);
          console.log(`Юзер хочет получить данные с ${url}, делаем реквест...`);
          request(url, (error, response, body) => {
            if (error) {
              console.log(`Произошла ошибка "${error.message}" пока делали реквест! :( Говорим это пользователю...`);
              cloudSession.set('☁ HTTPCloud_res', encode(error.message));
              console.log('Мы сказали это пользователю.');
            } else if (body.length > 128) {
              console.log(`Произошла ошибка "Response length is more than 128!" пока делали реквест! :( Говорим это пользователю...`);
              cloudSession.set('☁ HTTPCloud_res', encode('Response length is more than 128!'));
              console.log('Мы сказали это пользователю.');
            } else {
              console.log('Никаких ошибок, пока делали реквест не произошло! :) Говорим это пользователю...');
              var encoded = encode(body);
              cloudSession.set('☁ HTTPCloud_res', encoded);
              if(encoded === '18051916151419059503151420010914199519251302151219952008012095011805951415209519211616151820050443') return console.log('А хотя, ошибка есть.\nПроизошла ошибка "Response contains symbols that are not supported!".\nМы сказали это пользователю.');
              console.log('Мы сказали это пользователю!');
            }
          });
        }
			}
		});
	});
});